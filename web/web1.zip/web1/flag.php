<?php
$flag='gxnnctf{H0xIkKSSKS62UXPgLtCElE8jDCL7a2nqxDTT}';
?>
<!-- so dark!!!! -->