<?php
$white_list = range(0,9);
require_once('flag.php');
if(isset($_REQUEST['no'])){
    $a=$_REQUEST['no'];
    if(@ereg("^[0-9]+$", $a) === FALSE){
        echo 'no must be number';
    }else{
        if(in_array($a,$white_list)){
            if(strlen($a)>1){
                echo 'you are a great dark phper<br>';
                echo "<img src='dark.gif'><br>";
                echo $flag;
            }else{
                echo 'you no dark';
            }
        }else{
            echo 'you are so dark';
        }
    }    
}else
    highlight_file(__FILE__);


