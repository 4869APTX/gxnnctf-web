<?php
$db_servername = "localhost";
$db_username = "root";
$db_password = "root";
$db_name = "web5";
//from melonrind
?>