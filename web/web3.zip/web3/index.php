<?php
    $a=1;
    session_start();
    setcookie('flag');
    if(!isset($_SESSION['id'])){
        header("location:login.php");
    }else{
        $userid = $_SESSION['id'];
        $user = getUser($userid);
        $balance = $user['balance'];
        $vip_level = $user['vip_level'];
        if(isset($_GET['action'])&&isset($_GET['order'])){
            $action = $_GET['action'];
            $order = $_GET['order'];
            $order = json_decode(base64_decode($order));
            $good = $order->good;
            $price = $order->price;
            echo $balance;
            if($action == 'pay'){
                if($good==1&&$vip_level==1){
                    if(pay1check($balance,$price)){
                        if(pay($price,$userid)){
                            changeVip($userid);
                            alertError('you got it,now you are vip 2!!!take you green hat');
                        }else{
                            alertError('sql error');
                        }
                    }else{
                        alertError('you balance have some error');
                    }
                }elseif($good==2&&$vip_level!=1){
                    if(pay2check($balance)){
                        sleep(3);
                        $balance = $balance-501;
                        if(pay(501,$userid)){
                            changeVip($userid);
                            alertError('you got one super green hat!!!');
                        }else{
                            alertError('slq error');
                        }

                    }else{
                        alertError('you balance have some error');
                    }
                }else{
                    alertError('order have some error');
                }
                
            }else{
                alertError('action error!');
            }
        }else{
            pagehead();
            if($vip_level==1){
                echo <<<EOF
    <body>
        <a>you green level $vip_level</a>
        <br>
        <a>you balance is still $balance</a>
        <form method="post" action="index.php?order=eyJnb29kIjoxLCJwcmljZSI6NTAwfQ==&action=pay">
            <input  type="hidden" name="goods_info" id="info" value="test">
            <a>green hat(level 1) 500$</a>
            <button>buy this</button>
        </form>
        <br>
        <a href="login.php?action=logout">logout</a>

    </body>
    </html>
EOF;
            
            }elseif($vip_level==2){
                echo <<<EOF
            <body>
                <a>you green level is $vip_level</a>
                <br>
                <a>you balance is still $balance</a>
                <br>
                <a>if you want to get the big green hat,you have to buy two green hat(level2)</a>
                <form method="post" action="index.php?order=eyJnb29kIjoyLCJwcmljZSI6NTAxfQ==&action=pay">
                    <input  type="hidden" name="goods_info" id="info" value="test">
                    <a>green hat(level2) 501$</a>
                    <button>buy this</button>
                </form>
                <br>
                <a href="login.php?action=logout">logout</a>
        
            </body>
            </html>
EOF;
            }elseif($vip_level==3){
                echo <<<EOF
            <body>
                <a>you green level is $vip_level</a>
                <br>
                <a>you balance is still $balance</a>
                <br>
                <a>if you want to get the big green hat,you only have to buy one green hat(level2)</a>
                <form method="post" action="index.php?order=eyJnb29kIjoyLCJwcmljZSI6NTAxfQ==&action=pay">
                    <input  type="hidden" name="goods_info" id="info" value="test">
                    <a>green hat(level2) 501$</a>
                    <button>buy this</button>
                </form>
                <br>
                <a href="login.php?action=logout">logout</a>
        
            </body>
            </html>
EOF;
            }elseif($vip_level==4){
                echo "now you are green hat king,take you flag,good luck!!!<br>";
                echo "<img src='flag.gif'><br>";
                echo "gxnnctf{ZPXz1pYr247T98LogXEvePkXKkcspV9kDP88}";
            }
        }

        
        
    }

    function pagehead(){
        echo <<<EOF
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="utf-8"/>
            <meta http-equiv="X-UA-Compatible" content="IE=edge">
            <title>green shop</title>
            <meta name="viewport" content="width=device-width, initial-scale=1">
        </head>
EOF;
    }
// 检查price合法性
    function pay1check($balance,$price){
        if(@ereg("^[0-9]+$", $price) === FALSE){
            return 0;
        }
        if($price<0){
            return 0;
        }
        try{
            $price = (int)$price;
        }catch(Exception $e){
            echo 'eeee';
            return 0;
        }
        
        if($price<$balance){
            return 1;
        } 
    }

    function pay2check($balance){
        if($balance>501){
            return 1;
        }else{
            return 0;
        }
    }

    function pay($price,$userid){
        include 'config.php';
        $sql = 'update user set balance=balance-? where id = ?';
        $conn = new mysqli($dbservername,$dbusername,$dbpassword,$dbname);
        if($conn->connect_error){
               die("Connect failed:".$conn->connect_error);
        }
        $sql_stmt = $conn->prepare($sql);
        $sql_stmt->bind_param("ii",$price,$userid);
        if($sql_stmt->execute()){
            $sql_stmt->free_result();
            $sql_stmt->close();
            $conn->close();
            return TRUE;
        }else{
            $sql_stmt->free_result();
            $sql_stmt->close();
            $conn->close();
            return FALSE;
        }  
    }



    function changeVip($userid){
        include 'config.php';
        $sql = 'update user set vip_level=vip_level+1 where id = ?';
        $conn = new mysqli($dbservername,$dbusername,$dbpassword,$dbname);
        if($conn->connect_error){
               die("Connect failed:".$conn->connect_error);
        }
        $sql_stmt = $conn->prepare($sql);
        $sql_stmt->bind_param("i",$userid);
        if($sql_stmt->execute()){
            $sql_stmt->free_result();
            $sql_stmt->close();
            $conn->close();
            return TRUE;
        }else{
            $sql_stmt->free_result();
            $sql_stmt->close();
            $conn->close();
            return FALSE;
        } 
    }


    function getUser($userid){
        include 'config.php';
        $sql = 'select * from user where id = ?';
        $conn = new mysqli($dbservername,$dbusername,$dbpassword,$dbname);
        if($conn->connect_error){
               die("Connect failed:".$conn->connect_error);
        }
        $user = [];
        $sql_stmt = $conn->prepare($sql);
        $sql_stmt->bind_param("i",$userid);
        $sql_stmt->bind_result($user['id'],$user['username'],$a,$user['balance'],$user['vip_level']);
        $sql_stmt->execute();
        $sql_stmt->fetch();
        $sql_stmt->free_result();
        $sql_stmt->close();
        $conn->close();
        return $user;
        
    }

    function alertError($error){
        echo "<script>alert('$error');</script>";
        echo "<script language='javascript' type='text/javascript'>";
        echo "window.location.href='index.php'";
        echo "</script>";
    }
?>

