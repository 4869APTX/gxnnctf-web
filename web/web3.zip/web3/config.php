<?php
$dbservername = "localhost";
$dbusername = "root";
$dbpassword = "root";
$dbname = "web3";
//from melonrind
?>